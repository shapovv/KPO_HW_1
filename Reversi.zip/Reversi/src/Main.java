//Шаповалов Артём БПИ-217
public class Main {
    public static void main(String[] args) {
        Process process = new Process();
        process.start();
    }
}